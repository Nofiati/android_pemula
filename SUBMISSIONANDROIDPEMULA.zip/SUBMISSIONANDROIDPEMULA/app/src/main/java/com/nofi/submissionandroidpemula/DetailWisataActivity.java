package com.nofi.submissionandroidpemula;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class DetailWisataActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_wisata);
    }
}
